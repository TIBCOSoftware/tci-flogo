CREATE TABLE mon_appStatus(
   appId                   VARCHAR(100) NOT NULL PRIMARY KEY
  ,appName                 VARCHAR(100)
  ,appStatus               VARCHAR(100)
  ,instanceStatus_desired  INTEGER 
  ,instanceStatus_failed   INTEGER 
  ,instanceStatus_running  INTEGER 
  ,instanceStatus_starting INTEGER 
  ,instanceStatus_vpn      INTEGER 
  ,timestamp               VARCHAR(100)
);


CREATE TABLE mon_apps(
   appId                VARCHAR(100) NOT NULL PRIMARY KEY
  ,appName              VARCHAR(100) 
  ,appType              VARCHAR(100) 
  ,category             VARCHAR(100) 
  ,createdTime          VARCHAR(100)
  ,deploymentStage      VARCHAR(100) 
  ,deploymentType       VARCHAR(100) 
  ,desiredInstanceCount VARCHAR(100)
  ,endpointVisibility   VARCHAR(100) 
  ,lastStartedTime      VARCHAR(100)
  ,modifiedTime         VARCHAR(100)
  ,timestamp            VARCHAR(100)
);
