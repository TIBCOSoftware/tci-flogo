package com.tibco.tcm.pubsub;

import java.io.Serializable;

import com.tibco.bw.palette.shared.java.JavaProcessStarter;
import com.tibco.eftl.Connection;
import com.tibco.eftl.Message;
import com.tibco.eftl.SubscriptionListener;

@SuppressWarnings("rawtypes")
public class TCMJavaProcessStarter extends JavaProcessStarter implements Serializable{
	
	//the filter name using which messages would be subscribed to
	private String filterKey = "";
	//the corresponding filter value; for eg :  environment=UAT   ; environment is the key while UAT is the value
	private String filterValue = "";
	//the publishing app should publish message under this key; change as per publishing app
	private String payloadKey = "";
	//the name of the durable subscription
	private String durableName = "";
	
	
	private static final long serialVersionUID = 382355459314942562L;
	private GetMessages getMessages;
	private TCMConnection tcmConn;
	
	public TCMJavaProcessStarter() {
		System.out.println("java process starter constructor");
	}
	
	public void InitParams(String filterKey, String filterValue, String payloadKey, String durableName) {
		this.filterKey=filterKey;
		this.filterValue=filterValue;
		this.payloadKey = payloadKey;
		this.durableName = durableName;
		System.out.println("java process starter constructor");
		
	}
	
	

	public void init() throws Exception {
		// TODO Auto-generated method stub
		
	}

	public void onShutdown() {
		System.out.println("on shutdown");
		if(tcmConn!=null){
			tcmConn.disconnect();
			System.out.println("disconnected tcm from starter");
		}
	}

	public void onStart() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("on start lifecycle method");
		//Thread thread = new Thread(new GetMessages(this, tcmConnection));

		this.
		tcmConn = (TCMConnection)this.getJavaGlobalInstance();
		if (tcmConn == null) {
			System.err.println("Failed to get TIBCO Cloud Messaging Connection instance");
			System.exit(0);
		}
		System.out.println("on start lifecycle method tcm conn" + tcmConn);
		getMessages = new GetMessages(this, tcmConn.getTCMConnection(), this.filterKey, this.filterValue, this.payloadKey,this.durableName);
		Thread thread = new Thread(getMessages);
		thread.start();
	}

	public void onStop() throws Exception {
		System.out.println("on stop");
		if(getMessages != null){
			getMessages.setFlowControlEnabled(true);
			System.out.println("flow control enabled");
		}
	}
	
	public static class GetMessages implements Runnable {
		JavaProcessStarter javaProcessStarter;
		volatile boolean flowControl = false;
		Connection tcmConnection;
		private String filterKey = "";
		private String filterValue = "";
		@SuppressWarnings("unused")
		private String payloadKey = "";
		private String durableName = "";
		
		public GetMessages(JavaProcessStarter javaProcessStarter, 
				Connection tcmConnection,String filterKey,String filterValue, String payloadKey, String durableName) {
			this.javaProcessStarter = javaProcessStarter;
			this.tcmConnection = tcmConnection;
			this.filterKey = filterKey;
			this.filterValue = filterValue;
			this.payloadKey = payloadKey;
			this.durableName = durableName;
			System.out.println("tcm conn GetMessages " + tcmConnection);
		}
		
		public void run() {
			// TODO Auto-generated method stub
			System.out.println("tcm " + this.tcmConnection);
			System.out.println("filter " + "{\"" + this.filterKey + "\":" + "\"" + this.filterValue + "\"}");
			tcmConnection.subscribe("{\"" + this.filterKey + "\":" + "\"" + this.filterValue + "\"}", this.durableName ,new SubscriptionListener() {
			//tcmConnection.subscribe("{\"filterKey\":\"filterValue\"}", new SubscriptionListener() {
				
				public void onSubscribe(String arg0) {
					System.out.println("subscription completed successfully");
					
				}
				
				public void onMessages(Message[] messages) {
					for (Message message : messages) {
			            System.out.printf("received message: %s\n", message);
			            try {
			            	if(!flowControl){
			            		javaProcessStarter.onEvent(message.getString("payload"));
			            	}
							
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			        }
					
				}
				
				public void onError(String subscriptionId, int code, String reason) {
			        System.out.printf("subscription failed: %s\n", reason);
			    }
			});
			
		}
		
		public void setFlowControlEnabled(boolean flowControl) {
			this.flowControl = flowControl;
		}
	}
}