package com.tibco.tcm.pubsub;

@SuppressWarnings("serial")
public class TCMFunctions  implements java.io.Serializable {

	/**
	 * 
	 */
	
	private String msg=null;

	public TCMFunctions(String msg){
		this.msg = msg;
	}
	
	public String getMsg(){
		return msg;
	}
	
	public static String GetMessage(Object obj){
		return (String)obj;
	}

}
