package cl_utils

import (
	"crypto/hmac"
	"crypto/sha1"
	b64 "encoding/base64"
	"encoding/hex"
	"fmt"
	"strings"

	"github.com/project-flogo/core/data"
	"github.com/project-flogo/core/data/expression/function"
)

func init() {
	function.Register(&fnHmac{})
}

type fnHmac struct {
}

func (fnHmac) Name() string {
	return "hmac"
}

func computeDigest(secret, method, url, serial, time string) string {
	//	payloadBody := "GET+/api/v1/report/utilization+fdmdata+07 feb 2017 09:54:59"

	fmt.Println("======computeDigest =======")

	//secret := "8e453sf!"
	//secret := "fdmsecret"

	values := []string{method, url, serial, time}
	message := strings.Join(values, "+")
	fmt.Println("Message:" + message)
	hmacsha1 := hmac.New(sha1.New, []byte(secret))
	hmacsha1.Write([]byte(message))
	return b64.StdEncoding.EncodeToString([]byte(hex.EncodeToString(hmacsha1.Sum(nil))))
}

func (fnHmac) Sig() (paramTypes []data.Type, isVariadic bool) {
	return []data.Type{data.TypeString, data.TypeString, data.TypeString, data.TypeString, data.TypeString}, false
}

func (fnHmac) Eval(params ...interface{}) (interface{}, error) {
	return computeDigest(params[0].(string), params[1].(string), params[2].(string), params[3].(string), params[4].(string)), nil
}
