package custring

import (
	"encoding/json"
	"fmt"
	"testing"

	"github.com/project-flogo/core/data/expression/function"

	"github.com/stretchr/testify/assert"
)

var in = &fnMerge{}

func init() {
	function.ResolveAliases()
}

func TestInt64Sample(t *testing.T) {

	array1 := `[{"id":"123","age":"123"},{"id":"234","age":"234"},{"id":"456","age":"456"}]`

	array2 := `[{"id":"123", "name":"dddd"},{"id":"444", "name":"4444"},{"id":"456", "name":"456"},{"id":"555", "name":"5555"}]`

	final, err := in.Eval(array1, array2, "id", "==", "id")
	assert.Nil(t, err)
	v, _ := json.Marshal(final)
	fmt.Println(string(v))

	final, err = in.Eval(array2, array1, "id", "==", "id")
	assert.Nil(t, err)
	v, _ = json.Marshal(final)
	fmt.Println(string(v))
}
