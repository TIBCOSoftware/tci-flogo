package custring

import (
	"github.com/project-flogo/core/data"
	"github.com/project-flogo/core/data/coerce"
	"github.com/project-flogo/core/data/expression/function"
)

type fnUnMatching struct {
}

func init() {
	function.Register(&fnUnMatching{})
}

func (s *fnUnMatching) Name() string {
	return "unmatching"
}

func (s *fnUnMatching) Sig() (paramTypes []data.Type, isVariadic bool) {
	return []data.Type{data.TypeArray, data.TypeArray, data.TypeString, data.TypeString, data.TypeString}, false
}

func (s *fnUnMatching) Eval(in ...interface{}) (interface{}, error) {

	array1, err := coerce.ToArray(in[0])
	if err != nil {
		return nil, err
	}
	array2, err := coerce.ToArray(in[1])
	if err != nil {
		return nil, err
	}
	leftElement, err := coerce.ToString(in[2])
	if err != nil {
		return nil, err
	}

	operator, err := coerce.ToString(in[3])
	if err != nil {
		return nil, err
	}

	rightElelent, err := coerce.ToString(in[4])
	if err != nil {
		return nil, err
	}

	var unmatchingArray []interface{}
	array2Ids := make([]interface{}, len(array2))
	for i, v := range array2 {
		elementObj, _ := coerce.ToObject(v)
		if ele, ok := elementObj[rightElelent]; ok {
			s, _ := coerce.ToString(ele)
			array2Ids[i] = s
		} else {
			array2Ids[i] = nil
		}
	}

	for _, value := range array1 {
		elementObj, _ := coerce.ToObject(value)
		if ele, ok := elementObj[leftElement]; ok {
			s, _ := coerce.ToString(ele)
			if ok, _, err := containes(s, array2Ids, operator); !ok && err == nil {
				unmatchingArray = append(unmatchingArray, value)
			} else if err != nil {
				return nil, err
			}
		}
	}
	return unmatchingArray, nil
}
