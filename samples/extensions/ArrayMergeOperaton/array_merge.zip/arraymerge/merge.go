package custring

import (
	"fmt"
	"github.com/project-flogo/core/data"
	"github.com/project-flogo/core/data/coerce"
	"github.com/project-flogo/core/data/expression/function"
)

type fnMerge struct {
}

func init() {
	function.Register(&fnMerge{})
}

func (s *fnMerge) Name() string {
	return "merge"
}

func (s *fnMerge) Sig() (paramTypes []data.Type, isVariadic bool) {
	return []data.Type{data.TypeArray, data.TypeArray, data.TypeString, data.TypeString, data.TypeString}, false
}

func (s *fnMerge) Eval(in ...interface{}) (interface{}, error) {

	array1, err := coerce.ToArray(in[0])
	if err != nil {
		return nil, err
	}
	array2, err := coerce.ToArray(in[1])
	if err != nil {
		return nil, err
	}
	leftElement, err := coerce.ToString(in[2])
	if err != nil {
		return nil, err
	}

	operator, err := coerce.ToString(in[3])
	if err != nil {
		return nil, err
	}

	rightElelent, err := coerce.ToString(in[4])
	if err != nil {
		return nil, err
	}

	var mergedArray []interface{}
	array2Ids := make([]interface{}, len(array2))
	for i, v := range array2 {
		elementObj, _ := coerce.ToObject(v)
		if ele, ok := elementObj[rightElelent]; ok {
			s, _ := coerce.ToString(ele)
			array2Ids[i] = s
		} else {
			array2Ids[i] = nil
		}
	}

	for _, value := range array1 {
		elementObj, _ := coerce.ToObject(value)
		if ele, ok := elementObj[leftElement]; ok {
			s, _ := coerce.ToString(ele)
			if ok, i, err := containes(s, array2Ids, operator); ok && err == nil {
				arrayObj, _ := coerce.ToObject(array2[i])
				mergedArray = append(mergedArray, mergeMap(elementObj, arrayObj))
			} else if err != nil {
				return nil, err
			}
		}
	}
	return mergedArray, nil
}

func containes(item string, array []interface{}, operator string) (bool, int, error) {
	for i, v := range array {
		switch operator {
		case "==":
			if item == v {
				return true, i, nil
			}
		case ">":
			//TODO jus to float and compare
			f, _ := coerce.ToFloat64(item)
			f2, _ := coerce.ToFloat64(v)

			if f > f2 {
				return true, i, nil
			}
		case "<":
			f, _ := coerce.ToFloat64(item)
			f2, _ := coerce.ToFloat64(v)

			if f < f2 {
				return true, i, nil
			}
		case ">=":
			f, _ := coerce.ToFloat64(item)
			f2, _ := coerce.ToFloat64(v)

			if f >= f2 {
				return true, i, nil
			}
		case "<=":
			f, _ := coerce.ToFloat64(item)
			f2, _ := coerce.ToFloat64(v)

			if f <= f2 {
				return true, i, nil
			}
		default:
			return false, 0, fmt.Errorf("unkown opoerator [%s] for function arraymerge.merge", operator)
		}

	}
	return false, 0, nil
}

func mergeMap(map1, map2 map[string]interface{}) map[string]interface{} {
	if map1 == nil {
		map1 = make(map[string]interface{})
	}
	for k, v := range map2 {
		map1[k] = v
	}
	return map1
}
