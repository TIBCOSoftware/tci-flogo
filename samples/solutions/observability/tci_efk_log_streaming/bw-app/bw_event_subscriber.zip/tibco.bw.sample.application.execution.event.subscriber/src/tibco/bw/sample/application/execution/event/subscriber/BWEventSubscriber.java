package tibco.bw.sample.application.execution.event.subscriber;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

import org.osgi.service.event.Event;
import org.osgi.service.event.EventHandler;

import com.tibco.bw.runtime.AuditEvent;
import com.tibco.bw.runtime.event.ActivityAuditEvent;
import com.tibco.bw.runtime.event.ProcessAuditEvent;
import com.tibco.bw.runtime.event.State;
//import com.tibco.bw.runtime.event.TransitionAuditEvent;

// referenced in component.xml
public class BWEventSubscriber implements EventHandler {

	ConcurrentHashMap<String, Long> startTimes = new ConcurrentHashMap<String, Long>();
	ConcurrentHashMap<String, Long> processEvalTimes = new ConcurrentHashMap<String, Long>();

	@Override
    public void handleEvent(Event event) {
		AuditEvent auditEvent = (AuditEvent) event.getProperty("eventData");
		if(auditEvent instanceof ProcessAuditEvent) {
			//ProcessInstance data
			ProcessAuditEvent processEvent = (ProcessAuditEvent) auditEvent;
			Long startTime = processEvent.getProcessInstanceStartTime();
			Long endTime = null;
			State state = processEvent.getProcessInstanceState();
			if (state.equals(State.COMPLETED) || state.equals(State.FAULTED) || state.equals(State.CANCELLED)) {
				endTime = processEvent.getProcessInstanceEndTime();  
			}

			Long elapsedTime = null;
			//Long evalTime = null;
			if (startTime!=null) {
				startTimes.put(processEvent.getProcessInstanceId(), startTime);
			} else {
				if (endTime != null) {
					startTime = startTimes.remove(processEvent.getProcessInstanceId());
					if (startTime!=null) {
						elapsedTime = endTime - startTime;
					}
					//evalTime = processEvalTimes.remove(processEvent.getProcessInstanceId());
				}
			}

	        StringBuffer sb = new StringBuffer();
	        sb.append("{\"eventType\":\"ProcessInstanceEvent\",")
	          .append("\"appName\":\"").append(processEvent.getApplicationName()).append("\",")
	          .append("\"appVersion\":\"").append(processEvent.getApplicationVersion()).append("\",")
	          .append("\"processInstanceId\":\"").append(processEvent.getProcessInstanceId()).append("\",")
	          .append("\"processName\":\"").append(processEvent.getProcessName()).append("\",");
	        if (endTime!=null) {
		        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd hh:mm:ss.SSS");
                if (startTime!=null) {
                	Date date = new Date(startTime);
                	sb.append("\"startTime\":\"").append(sdf.format(date)).append("\",");
                }
		        Date date = new Date(endTime);
		        sb.append("\"endTime\":\"").append(sdf.format(date)).append("\",");
		        if (elapsedTime!=null)
		        	sb.append("\"executionTime\":\"").append(elapsedTime).append("\",");
	        }
	        sb.append("\"state\":\"").append(processEvent.getProcessInstanceState()).append("\"}");
	        System.out.println(sb.toString());
	        
		} else if(auditEvent instanceof ActivityAuditEvent) {
			// Activity data
			ActivityAuditEvent activityEvent = (ActivityAuditEvent) auditEvent;
			Long startTime = activityEvent.getActivityStartTime();
			Long endTime = activityEvent.getActivityEndTime();  
			Long elapsedTime = null;
			//Long processEvalTime = null;
			if (startTime!=null) {
				startTimes.put(((ActivityAuditEvent) auditEvent).getActivityExecutionId(), startTime);
			} else {
				if (endTime != null) {
					startTime = startTimes.remove(((ActivityAuditEvent) auditEvent).getActivityExecutionId());
					if (startTime != null) {
						elapsedTime = endTime - startTime;
					}
				}
			}
			
	        StringBuffer sb = new StringBuffer();
	        sb.append("{\"eventType\":\"activityEvent\",")
	          .append("\"appName\":\"").append(activityEvent.getApplicationName()).append("\",")
	          .append("\"appVersion\":\"").append(activityEvent.getApplicationVersion()).append("\",")
	          .append("\"processInstanceId\":\"").append(activityEvent.getProcessInstanceId()).append("\",")
	          .append("\"processName\":\"").append(activityEvent.getProcessName()).append("\",")
	          .append("\"activityName\":\"").append(activityEvent.getActivityName()).append("\",");
	        if (endTime!=null) {
		        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd hh:mm:ss.SSS");
		        if (startTime!=null) {
		        	Date date = new Date(startTime);
		        	sb.append("\"startTime\":\"").append(sdf.format(date)).append("\",");
		        }
		        Date date = new Date(endTime);
		        sb.append("\"endTime\":\"").append(sdf.format(date)).append("\",");
		        //sb.append("Eval Time:").append(activityEvent.getActivityEvalTime()).append("\n\t");
		        if (elapsedTime!=null)
		        	sb.append("\"executionTime\":\"").append(elapsedTime).append("\",");
		        /*
				processEvalTime = processEvalTimes.remove(activityEvent.getProcessInstanceId());
				if (processEvalTime == null) {
					processEvalTime = activityEvent.getActivityEvalTime();
				} else {
					processEvalTime = processEvalTime + activityEvent.getActivityEvalTime();
				}
				processEvalTimes.put(activityEvent.getProcessInstanceId(), processEvalTime);
				*/

	        }
	        sb.append("\"state\":\"").append(activityEvent.getActivityState()).append("\"}");
	        System.out.println(sb.toString());

		} /*else if(auditEvent instanceof TransitionAuditEvent) {
			//Transition data
		    System.out.println(auditEvent.toString());
		}*/
	}
	
}