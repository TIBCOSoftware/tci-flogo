import { Injectable } from "@angular/core";
import { BehaviorSubject, ReplaySubject, Subject } from "rxjs";

@Injectable({
    providedIn: 'root'
  })
  export class TokenService {
      tokenModalOpen = new BehaviorSubject<string>('close');

      openTokenModal(status:string): void{
          this.tokenModalOpen.next(status);
      }
  }