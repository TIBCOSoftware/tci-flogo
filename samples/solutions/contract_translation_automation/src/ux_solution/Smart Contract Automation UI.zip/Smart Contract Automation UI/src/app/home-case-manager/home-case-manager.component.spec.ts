import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeCaseManagerComponent } from './home-case-manager.component';

describe('HomeCaseManagerComponent', () => {
  let component: HomeCaseManagerComponent;
  let fixture: ComponentFixture<HomeCaseManagerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HomeCaseManagerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeCaseManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
