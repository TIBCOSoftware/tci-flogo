import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { TokenService } from './token.service';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CaseService {
  // headers;
  constructor(private http: HttpClient, private ts:TokenService) {
  }
  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': `Bearer `+environment.token,
  })

  public getAllCases(){
    let header = null;
    if(localStorage.getItem('token')){
      header = new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': `Bearer `+ localStorage.getItem('token'),
        })
    
    return this.http.get(environment.apiUrl + '/case/cases?%24sandbox=6440&%24filter=applicationId%20eq%205495%20and%20typeId%20eq%201&%24select=caseReference%2C%20summary&%24skip=0&%24top=100',
    {headers:header});
      }
      else{
        this.ts.openTokenModal('open');
       return of([]);
      }
  }

  public getParticularCase(caseId){
    // return this.http.get(environment.apiUrl + `/case/cases/${caseId}?%24sandbox=6440`,
    // {headers:this.headers});
    let header = null;
    if(localStorage.getItem('token')){
      header = new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': `Bearer `+ localStorage.getItem('token'),
        })
    
    return this.http.get(environment.apiUrl + `/case/cases/${caseId}?%24sandbox=6440`,
    {headers:header});
      }
      else{
        this.ts.openTokenModal('open');
       return of({});
      }
  }
  public getCaseId(caseId){
    let postObj = {"chatBotEnabled":false,"id":32234,"name":"Review","label":"Review","version":1,"applicationId":5495,"applicationName":"ContractCase","activityName":"Task","noData":false,"availableInStates":["Created","Under Review"],"roles":[],"performerPaths":[]};
    return this.http.post(environment.apiUrl + `/pageflow/caseActions/4602441?$sandbox=64400`, postObj,{headers:this.headers});
  }
  public updateCaseDetails(caseData){
    let postObj = {"id":"32234","sandboxId":"6440","applicationId":"5495","data":`{\"ContractCase\":{\"state\":\"${caseData.state}\",\"CompanyName\":\"${caseData.companyName}\",\"ContractType\":\"${caseData.ContractType}\",\"DocID\":\"${caseData.docId}\",\"srclang\":\"${caseData.srcLanguage}\"
    ,\"targetlang\":\"${caseData.targetLanguage}\",\"TranslatedDocID\":\"${caseData.targetId}\"}}`,"caseReference":`${caseData.caseReference}`};
    return this.http.post(environment.apiUrl + `/process/v1/processes`, JSON.stringify(postObj) ,{headers:this.headers});
  }

  public getCaseArtifacts(caseId){
    return this.http.get(environment.apiUrl + `/webresource/v1/caseFolders/${caseId}/artifacts/?$sandbox=6440&$top=100`,
    {headers:this.headers});
  }

  public downloadCaseArtifacts(caseId,artifcatsName,artifactsversion){
    console.log(artifcatsName)
    return this.http.get(environment.apiUrl + `/webresource/folders/${caseId}/6440/${artifcatsName}?$version=${artifactsversion}`,
    {headers:this.headers});
  }
}
