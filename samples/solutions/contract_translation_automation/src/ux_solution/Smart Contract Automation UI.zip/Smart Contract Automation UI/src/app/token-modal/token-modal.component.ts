import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { TokenService } from '../token.service';
@Component({
  selector: 'app-token-modal',
  templateUrl: './token-modal.component.html',
  styleUrls: ['./token-modal.component.css']
})
export class TokenModalComponent implements OnInit, AfterViewInit {
  closeResult = '';
  tokenInputForm: FormGroup;
  constructor(private modalService: NgbModal,private formBuilder: FormBuilder, private ts: TokenService) { }
  @ViewChild('content', { static: false }) content: ElementRef;
  ngOnInit(): void {
    this.tokenInputForm = this.formBuilder.group({
      tokenInput: ['']
    });
  }
  ngAfterViewInit(){
    this.ts.tokenModalOpen.subscribe((status:string)=>{
      if(status === 'open'){
        this.open(this.content);
      }
    })
  }
  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
      localStorage.setItem('token','CIC~97GFqX9a1N8WyKdc4VHP222K');
      window.location.reload();
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      console.log(this.tokenInputForm.value);
      return `with: ${reason}`;
    }
  }
}
