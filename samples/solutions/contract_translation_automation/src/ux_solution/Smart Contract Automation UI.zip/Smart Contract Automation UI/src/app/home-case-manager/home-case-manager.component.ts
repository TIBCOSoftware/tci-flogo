import { CaseService } from './../case.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home-case-manager',
  templateUrl: './home-case-manager.component.html',
  styleUrls: ['./home-case-manager.component.css']
})
export class HomeCaseManagerComponent implements OnInit {
  caseTemp: any;
  casesList: any;

  constructor(private router: Router,
              private caseService: CaseService) { }

  ngOnInit(): void {
    this.caseService.getAllCases().subscribe(res =>{
      this.caseTemp = res;
      this.caseTemp.forEach((element,index) => {
        let summary = JSON.parse(element.summary);
        this.caseTemp[index]['state'] = summary.state;
        this.caseTemp[index]['company'] = summary.CompanyName;
      });
      this.caseTemp.sort((a, b) => {
        let fa =  a.state.toLowerCase();
        let fb =  b.state.toLowerCase();
            if (fa < fb) {
                return 1;
            }
            if (fa > fb) {
                return -1;
            }
            return 0;
    })
      this.casesList = this.caseTemp;  
    })
    
  }

  public viewDetails(caseId){
    this.router.navigate(['casedetails',caseId]);
  }

}
