import { CaseService } from './../case.service';
import { ThrowStmt } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-case-details',
  templateUrl: './case-details.component.html',
  styleUrls: ['./case-details.component.css']
})
export class CaseDetailsComponent implements OnInit {
  showReview = true;
  showApproval = false;
  caseId;
  tokenError = false;
  model: any = {
    'companyName':'',
    'srcLanguage':'',
    'targetLanguage':'',
    'docId':'',
    'targetId':'',
    'state':''
  };
  caseDetails: Object;
  showForm = false;
  showCaseDetails = true;
  artifactsDetails: Object;
  constructor(private route: ActivatedRoute,
              private caseService: CaseService) { }

  ngOnInit(): void {
    this.caseId = this.route.snapshot.paramMap.get('caseId'); 
    this.caseService.getCaseId(this.caseId).subscribe(res =>{
      console.log(res);
    })
    this.getParticularCase();
  }

  public getParticularCase(){
    this.caseService.getParticularCase(this.caseId).subscribe(res=>{
      this.caseDetails = res;
      this.tokenError = false;
      if(Object.keys(this.caseDetails).length > 0){
      this.caseDetails['casedata'] = JSON.parse(this.caseDetails['casedata']);
      this.caseDetails['untaggedCasedata'] = JSON.parse(this.caseDetails['untaggedCasedata']);
      this.model.state = this.caseDetails['casedata']['state']
      this.model.companyName = this.caseDetails['casedata']['CompanyName'];
      this.model.srcLanguage = this.caseDetails['casedata']['srclang'];
      this.model.targetLanguage = this.caseDetails['casedata']['targetlang'];
      this.model.docId = this.caseDetails['casedata']['DocID'];
      this.model.targetId = this.caseDetails['casedata']['TranslatedDocID'];
      this.model.caseReference = this.caseDetails['caseReference'];
      this.model.ContractType = this.caseDetails['casedata']['ContractType'];
      }else{
        this.tokenError = true;
      }
    });

    this.caseService.getCaseArtifacts(this.caseId).subscribe(res=>{
      console.log(res);
      this.artifactsDetails = res;
    })
  }
  public reviewClick():void{
    this.showForm = true;
  }

  public approveClick():void{
    this.showApproval ? this.showApproval = false : this.showApproval = true;
  }

  public checkStatusClick():void{
    
  }

  cancelAction(){
    this.showForm = false;
  }

  public setDropdownItem(item): void{
    console.log(item)
    this.model.state = item;
  }

  public downloadDoc(name,version){
    window.location.href = `https://liveapps.cloud.tibco.com/webresource/folders/${this.caseId}/6440/${name}?$version=${version}`;
    this.caseService.downloadCaseArtifacts(this.caseId,name,version).subscribe((res:any) =>{
      
    })
  }

  public onSubmit(){
    this.showCaseDetails = false;
    this.caseService.updateCaseDetails(this.model).subscribe(res =>{
      console.log(res);
      this.getParticularCase();
      this.showCaseDetails = true;
      this.showForm = false;
    })
  }
}

