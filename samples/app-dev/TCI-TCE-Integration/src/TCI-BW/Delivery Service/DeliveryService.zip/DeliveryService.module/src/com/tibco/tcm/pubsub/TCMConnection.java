package com.tibco.tcm.pubsub;


import java.util.Properties;

import com.tibco.eftl.Connection;
import com.tibco.eftl.ConnectionListener;
import com.tibco.eftl.EFTL;
import com.tibco.eftl.Message;

public class TCMConnection{
	/**
	 * 
	 */
	Properties tcmProps = new Properties();
	
	private String authKey;
	private String clientId;
	private String url;
	private Connection tcmConnection;
	
	
	public TCMConnection(String url, String clientId, String authKey) throws InterruptedException {
		System.out.println("init tcm class");
		System.out.println("client id " + clientId);
		System.out.println("url " + url);
		System.out.println("authKey " + authKey);
		this.authKey = authKey;
		this.clientId = clientId;
		this.authKey = authKey;
		
		final Properties props = new Properties();

		// set the password using your authentication key
		props.setProperty(EFTL.PROPERTY_PASSWORD,
		              authKey);
		// provide a unique client identifier
		props.setProperty(EFTL.PROPERTY_CLIENT_ID, clientId);

		// connect to TIBCO Cloud Messaging
		EFTL.connect(url, props, new ConnectionListener() {
			public void onConnect(Connection connection) {
				if (connection != null) {
					tcmConnection = connection;
				}
				System.out.println("connected\n");
			}
		    public void onDisconnect(Connection connection, int code, String reason) {
		        System.out.println("disconnected: " + reason);
		    }
		    public void onReconnect(Connection connection) {
		        System.out.println("reconnected\n");
		    }
		    public void onError(Connection connection, int code, String reason) {
		        System.out.println("error: " + reason);
		    }
		});
		while(tcmConnection == null){
			Thread.sleep(200);
		}
		
	}
	
	public String getAuthKey() {
		return this.authKey;
	}
	
	public String getClientId() {
		return this.clientId;
	}
	
	public String getUrl() {
		return this.url;
	}
	
	public Connection getTCMConnection() {
		return this.tcmConnection;
	}
	
	public void disconnect(){
		this.tcmConnection.disconnect();
	}
	
	public void sendMessage(final String filterKey, final String filterValue, final String payloadKey ,final String payload ) {
		
	    final Message message = tcmConnection.createMessage();
	    
	    message.setString(payloadKey, payload);
	    message.setString(filterKey, filterValue);
	    
	    System.out.print(message);

	    
	    tcmConnection.publish(message, null);
	}
	
}