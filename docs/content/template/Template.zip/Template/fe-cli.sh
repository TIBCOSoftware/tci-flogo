#!/bin/bash
 
DEFAULT_ARGS="--rm -ti -v $PWD:/src -v ${PWD}/src/app:/gobuild/src -e GOPATH=/gobuild -p 7757:7757 --entrypoint /bin/bash"
if [ -f "${PWD}/.netrc" ]; then
    DEFAULT_ARGS="${DEFAULT_ARGS} -v ${PWD}/.netrc:/root/.netrc"
elif [ -f "${HOME}/.netrc" ]; then
    DEFAULT_ARGS="${DEFAULT_ARGS} -v ${HOME}/.netrc:/root/.netrc"
fi

docker run ${DEFAULT_ARGS} reldocker.tibco.com/tci/tci-flogo-cli:1687 $@
