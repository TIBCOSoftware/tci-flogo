package connection

import (
	"github.com/project-flogo/core/data/coerce"
	"github.com/project-flogo/core/support/connection"
	"github.com/project-flogo/core/support/log"
)

var logger = log.ChildLogger(log.RootLogger(), "template-connection")

var factory = &awsFactory{}

type templateConn struct {
	Name   string `md:"name"`
	Field1 string `md:"connProperty1"`
}

func init() {
	err := connection.RegisterManagerFactory(factory)
	if err != nil {
		panic(err)
	}
}

type awsFactory struct {
}

func (*awsFactory) Type() string {
	return "template"
}

func (*awsFactory) NewManager(settings map[string]interface{}) (connection.Manager, error) {
	awsManger := &awsManager{}

	name, _ := coerce.ToString(settings["name"])
	field, _ := coerce.ToString(settings["connProperty1"])
	conn := &templateConn{
		Name:   name,
		Field1: field,
	}

	awsManger.conn = conn
	return awsManger, nil
}

type awsManager struct {
	conn *templateConn
}

func (a *awsManager) Type() string {
	return "templateConn"
}

func (a *awsManager) GetConnection() interface{} {
	//Return connection here
	return a.conn
}

func (a *awsManager) ReleaseConnection(connection interface{}) {
	//No nothing for aws connection
}
