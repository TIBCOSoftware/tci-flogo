
import {Injectable, Injector} from "@angular/core";
import {Http} from "@angular/http";
import {Observable} from "rxjs/Observable";
import {
    ActionResult,
    CreateFlowActionResult,
    IActionResult,
    IConnectorContribution,
    ICreateFlowActionContext,
    IFieldDefinition,
    ITriggerContribution,
    IValidationResult,
    ValidationResult,
    WiContrib,
    ITriggerElement,
    WiContribModelService,
    WiContributionUtils,
    WiServiceHandlerContribution
} from "wi-studio/app/contrib/wi-contrib";

@WiContrib({})
@Injectable()
export class trigger1Handler extends WiServiceHandlerContribution {

    constructor(private injector: Injector, private http: Http, private contribModelService: WiContribModelService) {
        super(injector, http, contribModelService);
    }

    value = (fieldName: string, context: ITriggerContribution): Observable<any> | any => {
        return Observable.create(observer => {
            observer.next("");
        });
    }

    validate = (fieldName: string, context: ITriggerContribution): Observable<IValidationResult> | IValidationResult => {
        if (fieldName === "field1") {
            let valueType: IFieldDefinition = context.getField("field1");
            if (valueType && valueType.value !== "template") {
                return ValidationResult.newValidationResult().setError("VALIDATE", "Validation error, please type `template` to pass by");
            } else {
                return ValidationResult.newValidationResult().setVisible(true);
            }
        }
    }

    action = (actionId: string, context: ITriggerContribution): Observable<IActionResult> | IActionResult => {
        return Observable.create(observer => {
            let aresult: IActionResult = ActionResult.newActionResult();
            observer.next(aresult);
            let modelService = this.getModelService();
            let result = CreateFlowActionResult.newActionResult();
            if (context.handler && context.handler.settings && context.handler.settings.length > 0) {
                let settingField1 = <IFieldDefinition>context.getField("settingField1");
                if (settingField1 && settingField1.value) {
                    let trigger = modelService.createTriggerElement("Template/trigger1");
                    for (let j = 0; j < context.settings.length; j++) {
                        if (context.settings[j].value && context.settings[j].name === "settingField1") {
                            trigger.settings[j] = settingField1.value
                        }
                    }

                    let handleField1 = <IFieldDefinition>context.getField("handleField1");
                    if (trigger && trigger.handler && trigger.handler.settings && trigger.handler.settings.length > 0) {
                        for (let j = 0; j < trigger.handler.settings.length; j++) {
                            if (trigger.handler.settings[j].name === "handleField1") {
                                trigger.handler.settings[j].value = handleField1.value;
                                continue;
                            }
                        }
                    }

                    // if (trigger && trigger.outputs  && trigger.outputs.length > 0) {
                    //     for (let j = 0; j < trigger.outputs.length; j++) {
                    //         if (messageSchema && messageSchema.value && trigger.outputs[j].name === "message") {
                    //             trigger.outputs[j].value = messageSchema.value;
                    //             break;
                    //         }
                    //     }
                    // }
                    this.doTriggerMapping(trigger);
                    let flowModel = modelService.createFlow(context.getFlowName(), context.getFlowDescription());
                    result = result.addTriggerFlowMapping(lodash.cloneDeep(trigger), lodash.cloneDeep(flowModel));
                }
            }

            let actionResult = ActionResult.newActionResult().setSuccess(true).setResult(result);
            return actionResult;
        });
    }

    doTriggerMapping(trigger: ITriggerElement) {
        let outputMappingElement = this.contribModelService.createMapping();
        outputMappingElement.addMapping("$INPUT['outputField1']", this.contribModelService.createMapExpression().setExpression("$trigger.outputField1"));
        outputMappingElement.addMapping("$INPUT['outputField2']", this.contribModelService.createMapExpression().setExpression("$trigger.outputField2"));
        (<any>trigger).inputMappings = outputMappingElement;
    }
}

