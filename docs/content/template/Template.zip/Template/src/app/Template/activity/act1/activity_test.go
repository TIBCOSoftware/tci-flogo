
package act2

import (
    "github.com/project-flogo/core/data/mapper"
    "github.com/project-flogo/core/data/resolve"
    "github.com/project-flogo/core/support/test"
    "github.com/stretchr/testify/assert"
    "testing"
)

func TestSimpleCall(t *testing.T) {

    // Set Settings field
    settings := &Settings{Field: "Settings field"}
    mf := mapper.NewFactory(resolve.GetBasicResolver())
    iCtx := test.NewActivityInitContext(settings, mf)
    act, err := New(iCtx)
    assert.Nil(t, err)

    tc := test.NewActivityContext(act.Metadata())
    //Setting input fields
    tc.SetInput("field1",map[string]interface{}{"id":"xxxx"})

    //eval
    act.Eval(tc)

    assert.NotNil(t, tc.GetOutput("field1"))

    //Checking output field
    assert.Equal(t, "This is output", tc.GetOutput("field1"))

}