package connection

import (
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/project-flogo/core/support/connection"
	"github.com/project-flogo/core/support/log"
)

var logger = log.ChildLogger(log.RootLogger(), "template-connection")

var factory = &awsFactory{}

type awsConnection struct {
	Name   string `md:"name"`
	Region string `md:"region"`
	Field1 bool   `md:"field1"`
}

func init() {
	err := connection.RegisterManagerFactory(factory)
	if err != nil {
		panic(err)
	}
}

type awsFactory struct {
}

func (*awsFactory) Type() string {
	return "template"
}

func (*awsFactory) NewManager(settings map[string]interface{}) (connection.Manager, error) {
	awsManger := &awsManager{}
	return awsManger, nil
}

type awsManager struct {
	config  *awsConnection
	session *session.Session
}

func (a *awsManager) Type() string {
	return "templateConn"
}

func (a *awsManager) GetConnection() interface{} {
	//Return connection here
	return nil
}

func (a *awsManager) ReleaseConnection(connection interface{}) {
	//No nothing for aws connection
}
