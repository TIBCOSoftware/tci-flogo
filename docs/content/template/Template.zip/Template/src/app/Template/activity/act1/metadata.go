package act2

import "github.com/project-flogo/core/data/coerce"

type Settings struct {
	Field string `md:"settingProperty1"` // The HTTP method to invoke
}

type Input struct {
	Field1 map[string]interface{} `md:"inputProperty1"`
}

func (i *Input) ToMap() map[string]interface{} {
	return map[string]interface{}{
		"inputProperty1": i.Field1,
	}
}

func (i *Input) FromMap(values map[string]interface{}) error {
	var err error
	i.Field1, err = coerce.ToObject(values["inputProperty1"])
	if err != nil {
		return err
	}
	return nil
}

type Output struct {
	Field1 string `md:"outputProperty1"` // The HTTP status code
}

func (o *Output) ToMap() map[string]interface{} {
	return map[string]interface{}{
		"outputProperty1": o.Field1,
	}
}

func (o *Output) FromMap(values map[string]interface{}) error {
	var err error
	o.Field1, err = coerce.ToString(values["outputProperty1"])
	if err != nil {
		return err
	}
	return nil
}
