package trigger1

import (
	"context"
	"fmt"
	"testing"

	"github.com/project-flogo/core/api"
	"github.com/project-flogo/core/engine"
)

func Test_App(t *testing.T) {
	app := myApp()

	e, err := api.NewEngine(app)

	if err != nil {
		fmt.Println("Error:", err)
		return
	}
	//assert.Nil(t, err)

	go engine.RunEngine(e)

	fmt.Println("The response is")
}

func myApp() *api.App {

	app := api.NewApp()

	trg := app.NewTrigger(&Trigger{}, &Settings{Field1: "setting field1"})

	h, _ := trg.NewHandler(&HandlerSettings{HandleField1: "handler field1", HandleField2: "handler field1"})

	h.NewAction(RunActivities)
	return app
}

func RunActivities(ctx context.Context, inputs map[string]interface{}) (map[string]interface{}, error) {
	result := &Reply{Data: "hello"}
	return result.ToMap(), nil
}
