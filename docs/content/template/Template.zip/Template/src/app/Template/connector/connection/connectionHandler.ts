
import {Injectable, Injector} from "@angular/core";
import {Http} from "@angular/http";
import {Observable} from "rxjs/Observable";
import {
    WiContrib,
    WiServiceHandlerContribution,
    IValidationResult,
    ValidationResult,
    ValidationError,
    IContributionTypes,
    ActionResult,
    IActionResult,
    WiContribModelService,
    WiContributionUtils,
    IConnectorContribution,
    AUTHENTICATION_TYPE
} from "wi-studio/app/contrib/wi-contrib";


@WiContrib({})
@Injectable()
export class connectionHandler extends WiServiceHandlerContribution {

    constructor(private injector: Injector, private http: Http) {
                    super(injector, http);
                }

    value = (fieldName: string, context: IConnectorContribution): Observable<any> | any => {
        return Observable.create(observer => {
            observer.next(null);
        });
    }

    validate = (fieldName: string, context: IConnectorContribution): Observable<IValidationResult> | IValidationResult => {
        return Observable.create(observer => {
            let vresult: IValidationResult = ValidationResult.newValidationResult();
            observer.next(vresult);
        });
    }

    action = (actionId: string, context: IConnectorContribution): Observable<IActionResult> | IActionResult => {
        if (actionId === "Save Connector") {
            return Observable.create(observer => {
                let currentName = "";
                for (let i = 0; i < context.settings.length; i++) {
                    if (context.settings[i].name === "name") {
                        currentName = context.settings[i].value;
                        break;
                    }
                }
                let duplicate = false;
                WiContributionUtils.getConnections(this.http, "Template").subscribe((conns: IConnectorContribution[]) => {
                    for (let conn of conns) {
                        for (let i = 0; i < conn.settings.length; i++) {
                            if (conn.settings[i].name === "name") {
                                let oldName = conn.settings[i].value;
                                if (oldName === currentName && (WiContributionUtils.getUniqueId(conn) !== WiContributionUtils.getUniqueId(context))) {
                                    duplicate = true;
                                    break;
                                }
                            }
                        }
                    }

                    if (duplicate) {
                        observer.next(ActionResult.newActionResult().setSuccess(false).setResult(new ValidationError("BASIC-1000", "Connection name already exist !!!")));
                        observer.complete();
                    } else {
                        let actionResult = {
                            context: context,
                            authType: AUTHENTICATION_TYPE.BASIC,
                            authData: {}
                        };
                        observer.next(ActionResult.newActionResult().setResult(actionResult));
                    }
                })
            });
        }
    }
}

