
import {Injectable, Injector} from "@angular/core";
import {Http} from "@angular/http";
import {Observable} from "rxjs/Observable";
import * as lodash from "lodash";
import {
    ActionResult,
    CreateFlowActionResult,
    IActionResult,
    IConnectorContribution,
    ICreateFlowActionContext,
    IFieldDefinition,
    ITriggerContribution,
    IValidationResult,
    ValidationResult,
    WiContrib,
    ITriggerElement,
    WiContribModelService,
    WiContributionUtils,
    WiServiceHandlerContribution
} from "wi-studio/app/contrib/wi-contrib";

@WiContrib({})
@Injectable()
export class trigger1Handler extends WiServiceHandlerContribution {

    constructor(private injector: Injector, private http: Http, private contribModelService: WiContribModelService) {
        super(injector, http, contribModelService);
    }

    value = (fieldName: string, context: ITriggerContribution): Observable<any> | any => {
        if (fieldName === "connection") {
            return Observable.create(observer => {
                let connectionRefs = [];
                WiContributionUtils.getConnections(this.http, "Template").subscribe((data: IConnectorContribution[]) => {
                    console.log("connection ref response: ", data)
                    data.forEach(connection => {
                        for(let i=0; i < connection.settings.length; i++) {
                            if (connection.settings[i].name === "name") {
                                connectionRefs.push({
                                    "unique_id": WiContributionUtils.getUniqueId(connection),
                                    "name": connection.settings[i].value
                                });
                                break;
                            }
                        }
                    });
                    observer.next(connectionRefs);
                });
            });
        }
    }

    validate = (fieldName: string, context: ITriggerContribution): Observable<IValidationResult> | IValidationResult => {
        if (fieldName === "field1") {
            let valueType: IFieldDefinition = context.getField("field1");
            if (valueType && valueType.value !== "template") {
                return ValidationResult.newValidationResult().setError("VALIDATE", "Validation error, please type `template` to pass by");
            } else {
                return ValidationResult.newValidationResult().setVisible(true);
            }
        }if (fieldName === "handleField2") {
            let valueType: IFieldDefinition = context.getField("handleField2");
            if (valueType && valueType.value !== "template") {
                return ValidationResult.newValidationResult().setError("VALIDATE", "Validation error, please type `template` to pass by");
            } else {
                return ValidationResult.newValidationResult().setVisible(true);
            }
        }
    }

    action = (actionId: string, context: ICreateFlowActionContext): Observable<IActionResult> | IActionResult => {
            let modelService = this.getModelService();
            let result = CreateFlowActionResult.newActionResult();
            if (context.handler && context.handler.settings && context.handler.settings.length > 0) {
                let trigger = modelService.createTriggerElement("Template/trigger1");
                let connectionField = <IFieldDefinition>context.getField("connection");
                let handleField1 = <IFieldDefinition>context.getField("handleField1");
                let handleField2 = <IFieldDefinition>context.getField("handleField2");

                if (trigger && trigger.settings && trigger.settings.length > 0) {
                    for (let j = 0; j < trigger.settings.length; j++) {
                        if (trigger.settings[j].name === "connection") {
                            trigger.settings[j].value = connectionField.value;
                            continue;
                        }
                    }
                }

                if (trigger && trigger.handler && trigger.handler.settings && trigger.handler.settings.length > 0) {
                        for (let j = 0; j < trigger.handler.settings.length; j++) {
                            if (trigger.handler.settings[j].name === "handleField1") {
                                trigger.handler.settings[j].value = handleField1.value;
                                continue;
                            }

                            if (trigger.handler.settings[j].name === "handleField2") {
                                trigger.handler.settings[j].value = handleField2.value;
                                continue;
                            }
                        }
                }

                this.doTriggerMapping(trigger);
                let flowModel = modelService.createFlow(context.getFlowName(), context.getFlowDescription());
                result = result.addTriggerFlowMapping(lodash.cloneDeep(trigger), lodash.cloneDeep(flowModel));
            }

            let actionResult = ActionResult.newActionResult().setSuccess(true).setResult(result);
            return actionResult;
    }

    doTriggerMapping(trigger: ITriggerElement) {
        let outputMappingElement = this.contribModelService.createMapping();
        outputMappingElement.addMapping("$INPUT['outputField1']", this.contribModelService.createMapExpression().setExpression("$trigger.outputField1"));
        outputMappingElement.addMapping("$INPUT['outputField2']", this.contribModelService.createMapExpression().setExpression("$trigger.outputField2"));
        (<any>trigger).inputMappings = outputMappingElement;
    }
}

