package trigger1

import (
	"context"

	"github.com/project-flogo/core/data/metadata"
	"github.com/project-flogo/core/support/log"
	"github.com/project-flogo/core/trigger"
)

const (
	CorsPrefix = "REST_TRIGGER"
)

var triggerMd = trigger.NewMetadata(&Settings{}, &HandlerSettings{}, &Output{}, &Reply{})

func init() {
	_ = trigger.Register(&Trigger{}, &Factory{})
}

type Factory struct {
}

// Metadata implements trigger.Factory.Metadata
func (*Factory) Metadata() *trigger.Metadata {
	return triggerMd
}

// New implements trigger.Factory.New
func (*Factory) New(config *trigger.Config) (trigger.Trigger, error) {
	s := &Settings{}
	err := metadata.MapToStruct(config.Settings, s, true)
	if err != nil {
		return nil, err
	}
	return &Trigger{id: config.Id, settings: s}, nil
}

// Trigger REST trigger struct
type Trigger struct {
	settings *Settings
	id       string
	logger   log.Logger
	handlers []trigger.Handler
}

func (t *Trigger) Initialize(ctx trigger.InitContext) error {
	// Init handlers
	ctx.Logger().Infof("Trigger settings fields: %+v", t.settings)
	t.handlers = ctx.GetHandlers()
	return nil
}

func (t *Trigger) Start() error {
	for _, h := range t.handlers {
		go startHandler(h)
	}
	return nil
}

func startHandler(h trigger.Handler) {
	h.Logger().Infof("handler settings field: %+v", h.Settings())
	result, err := h.Handle(context.Background(), nil)
	if err != nil {
		h.Logger().Error(err)
	}

	h.Logger().Infof("Handler returned data: %+v", result)
}

// Stop implements util.Managed.Stop
func (t *Trigger) Stop() error {
	// Clean up trigger stuff
	return nil
}
