package trigger1

import (
	"github.com/project-flogo/core/data/coerce"
	"github.com/project-flogo/core/support/connection"
)

type Settings struct {
	Connection connection.Manager `md:"connection"`
	Field1     string             `md:"settingField1"`
}

type HandlerSettings struct {
	HandleField1 string `md:"handleField1"`
	HandleField2 string `md:"handleField2"`
}

type Output struct {
	OutputField1 string                 `md:"outputField1"`
	OutputField2 map[string]interface{} `md:"outputField2"`
}

type Reply struct {
	Data interface{} `md:"data"`
}

func (o *Output) ToMap() map[string]interface{} {
	return map[string]interface{}{
		"outputField1": o.OutputField1,
		"outputField2": o.OutputField2,
	}
}

func (o *Output) FromMap(values map[string]interface{}) error {

	var err error
	o.OutputField1, err = coerce.ToString(values["outputField1"])
	if err != nil {
		return err
	}
	o.OutputField2, err = coerce.ToObject(values["outputField2"])
	if err != nil {
		return err
	}

	return nil
}

func (r *Reply) ToMap() map[string]interface{} {
	return map[string]interface{}{
		"data": r.Data,
	}
}

func (r *Reply) FromMap(values map[string]interface{}) error {
	r.Data, _ = values["data"]
	return nil
}
